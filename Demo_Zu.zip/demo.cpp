// 24780 Individual Project
// Wuzhou Zu (wuzhouz@andrew.cmu.edu)
// 10.05.2020

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#include "yssimplesound.h"
#include "yspng.h"
#include "fssimplewindow.h"

const int nTargets = 10;
const int nMissiles = 1;
const int nParticlePerExplosion = 50;
const double PI = 3.1415927;

class Explosion
{
public:
	int state, counter;
	int xy[nParticlePerExplosion * 2];
	int vxvy[nParticlePerExplosion * 2];
	void Initialize(void);
	bool Begin(int x, int y);
	void Move(void);
	void Draw(void);
	void Disappear(void);
};
void Explosion::Initialize(void)
{
	state = 0;
}
bool Explosion::Begin(int x, int y)
{
	if (0 == state)
	{
		state = 1;
		counter = 0;
		for (int i = 0; i < nParticlePerExplosion; ++i)
		{
			xy[i * 2] = x;
			xy[i * 2 + 1] = y;
			vxvy[i * 2] = rand() % 11 - 5;
			vxvy[i * 2 + 1] = rand() % 11 - 5;
		}
		return true;
	}
	return false;
}
void Explosion::Move(void)
{
	for (int i = 0; i < nParticlePerExplosion; ++i)
	{
		xy[i * 2] += vxvy[i * 2];
		xy[i * 2 + 1] += vxvy[i * 2 + 1];
	}

	++counter;
	if (50 < counter)
	{
		Disappear();
	}
}
void Explosion::Draw(void)
{
	glPointSize(7);
	glColor3ub(255, 91, 20);
	glBegin(GL_POINTS);
	for (int i = 0; i < nParticlePerExplosion; ++i)
	{
		glVertex2i(xy[i * 2], xy[i * 2 + 1]);
	}
	glEnd();
}
void Explosion::Disappear(void)
{
	state = 0;
}

void DrawCraft(int x, int y)
{
	glBegin(GL_QUADS);

	glVertex2i(x - 3, y);
	glVertex2i(x - 3, y - 36);
	glVertex2i(x + 3, y - 36);
	glVertex2i(x + 3, y);

	glEnd();
}

void DrawMissile(int x, int y)
{
	//glColor3ub(150, 120, 190);
	glBegin(GL_TRIANGLES);
	glVertex2i(x - 3, y + 6);
	glVertex2i(x + 3, y + 6);
	glVertex2i(x, y - 6);
	glEnd();
}

//Color gradation on enemies
//void DrawEnemy(int x, int y, int w, int h)
//{
//	glBegin(GL_QUADS);
//
//	glVertex2i(x, y);
//
//	glVertex2i(x + w, y);
//
//	glVertex2i(x + w, y + h);
//
//	glVertex2i(x, y + h);
//	glEnd();
//}

bool CheckTargetCollision(int mx, int my, int tx, int ty, int tw, int th)
{
	double dx = fabs(double(mx - tx));
	double dy = fabs(double(my - ty));
	if (0 <= dx && dx < tw && 0 <= dy && dy < th)
	{
		return true;
	}
	return false;
}

class Target
{
public:
	int x, y, state, w, h, v;
	void Initialize(void);
};

// Create falling targets with random size and speed
void Target::Initialize(void)
{
	y = -50 - rand() % 750;
	x = 100 + rand() % 385;
	w = 30;
	h = 60;
	v = 1;
	state = 1;
}

class Missile
{
public:
	int x[3], y, state;
	void Initialize(void);
};

void Missile::Initialize(void)
{
	state = 0;
}

int main(void)
{
	//Initialize sound player
	YsSoundPlayer player;
	YsSoundPlayer::SoundData bangSE;
	YsSoundPlayer::SoundData missileSE;
	/*
	  In Windows/Linux: Put .WAV in the same directory as .EXE
	  In macOS: Put .WAV in ???.app/Contents/Resources
	*/
	FsChangeToProgramDir();
	if (YSOK != bangSE.LoadWav("Explosion.wav") ||
		YSOK != missileSE.LoadWav("Fire.wav"))
	{
		printf("Load error.\n");
		return 1;
	}

	unsigned int t0;
	t0 = time(NULL);
	srand(t0);
	int score = 0;
	int missileUsed = 0;
	double x = 300, y = 700;
	double vx = 0.85;


	Missile missile[nMissiles];
	Target target[nTargets];
	Explosion explosion[nTargets];

	for (auto& t : target)
	{
		t.Initialize();
	}
	for (auto& e : explosion)
	{
		e.Initialize();
	}
	for (auto& m : missile)
	{
		m.Initialize();
	}

	YsRawPngDecoder png[3];
	GLuint texId[3];

	FsOpenWindow(16, 16, 600, 800, 1);
	FsChangeToProgramDir();

	png[0].Decode("Space.png");
	png[1].Decode("BattleShipYamato.png");
	png[2].Decode("Asteroid.png");
	glGenTextures(1, &texId[0]);  // Reserve one texture identifier
	glBindTexture(GL_TEXTURE_2D, texId[0]);  // Making the texture identifier current (or bring it to the deck)

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

	glTexImage2D
	(GL_TEXTURE_2D,
		0,    // Level of detail
		GL_RGBA,
		png[0].wid,
		png[0].hei,
		0,    // Border width, but not supported and needs to be 0.
		GL_RGBA,
		GL_UNSIGNED_BYTE,
		png[0].rgba);

	glGenTextures(1, &texId[1]);  // Reserve one texture identifier
	glBindTexture(GL_TEXTURE_2D, texId[1]);  // Making the texture identifier current (or bring it to the deck)

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

	glTexImage2D
	(GL_TEXTURE_2D,
		0,
		GL_RGBA,
		png[1].wid,
		png[1].hei,
		0,
		GL_RGBA,
		GL_UNSIGNED_BYTE,
		png[1].rgba);

	glGenTextures(1, &texId[2]);  // Reserve one texture identifier
	glBindTexture(GL_TEXTURE_2D, texId[2]);  // Making the texture identifier current (or bring it to the deck)

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

	glTexImage2D
	(GL_TEXTURE_2D,
		0,
		GL_RGBA,
		png[2].wid,
		png[2].hei,
		0,
		GL_RGBA,
		GL_UNSIGNED_BYTE,
		png[2].rgba);
	
	player.Start();

	for(;;)
	{
		player.KeepPlaying();

		FsPollDevice();
		
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		glColor4d(1.0, 1.0, 1.0, 1.0);

		glEnable(GL_TEXTURE_2D);  // Begin using texture mapping
		//Draw Background
		glBindTexture(GL_TEXTURE_2D, texId[0]);

		glBegin(GL_QUADS);

		glTexCoord2d(0.0, 0.0);
		glVertex2i(0, 0);

		glTexCoord2d(1.0, 0.0);
		glVertex2i(600, 0);

		glTexCoord2d(1.0, 1.0);
		glVertex2i(600, 800);

		glTexCoord2d(0.0, 1.0);
		glVertex2i(0, 800);

		glEnd();

		glDisable(GL_TEXTURE_2D);  // End using texture mapping

		
		if (0 != FsGetKeyState(FSKEY_ESC))
		{
			break;
		}

		x += vx;
		if (x >= 575 || x <= 25)
		{
			vx = -vx;
		}

		int r = rand() % 50;
		if (r == 1)
		{
			for (auto& m : missile)
			{
				if (0 == m.state)
				{
					player.PlayOneShot(missileSE);

					for (int i = 0; i < 3; i++)
					{
						m.state = 1;
						m.x[i] = x - 10 + 8 * i;
						m.y = y;
					}

					++missileUsed;
					break;
				}
			}
		}
		
		for (int i = 0; i < nTargets; ++i)
		{
			auto& e = explosion[i];
			e.Move();
		}
		for (auto& m : missile)
		{
			if (0 != m.state)
			{
				m.y -= 8;
				if (m.y < 0)
				{
					m.state = 0;
				}
			}
		}
		for (auto& t : target)
		{
			if (0 != t.state)
			{
				t.y += t.v;
				if (950 <= t.y)
				{
					t.y = 0 - rand() % 900;
					t.x = 100 + rand() % 420;
				}
				//x += vx;
				//if (x >= 575 || x <= 25)
				//{
				//	vx = -vx;
				//}
			}
		}

		for (auto& m : missile)
		{
			if (0 != m.state)
			{
				bool shotDown = false;
				int nTargetsAlive = 0;
				for (auto& t : target)
				{
					for (int i = 0; i < 3; i++)
					{
						if (0 != t.state && 0 != m.state && true == CheckTargetCollision(m.x[i], m.y, t.x, t.y, t.w, t.h))
						{
							player.PlayOneShot(bangSE);
							for (int i = 0; i < nTargets; ++i)
							{
								auto& e = explosion[i] ;
								if (true == e.Begin(*m.x, m.y))
								{
									m.state = 0;
									t.state = 0;
									break;
								}
							}
						}
					}
					shotDown = true;
					nTargetsAlive += t.state;
				}
			}
		}

		for (auto& m : missile)
		{
			if (0 != m.state)
			{
				for (int i = 0; i < 3; i++)
				{
					DrawMissile(m.x[i], m.y);
				}
			}
		}
		// Draw asteroid
		glEnable(GL_TEXTURE_2D);  // Begin using texture mapping
		for (auto& t : target)
		{
			if (0 != t.state)
			{
				glBindTexture(GL_TEXTURE_2D, texId[2]);

				glBegin(GL_QUADS);

				glTexCoord2d(0.0, 0.0);
				glVertex2i(t.x - t.w, t.y - t.h);

				glTexCoord2d(1.0, 0.0);
				glVertex2i(t.x + t.w, t.y - t.h);

				glTexCoord2d(1.0, 1.0);
				glVertex2i(t.x + t.w, t.y + t.h);

				glTexCoord2d(0.0, 1.0);
				glVertex2i(t.x - t.w, t.y + t.h);

				glEnd();
			}

		}

		// Draw Battleship
		glBindTexture(GL_TEXTURE_2D, texId[1]);

		glBegin(GL_QUADS);

		glTexCoord2d(0.0, 0.0);   // For each vertex, assign texture coordinate before vertex coordinate.
		glVertex2d(x - 15.0, y - 90.0);

		glTexCoord2d(1.0, 0.0);
		glVertex2d(x + 15.0, y - 90.0);

		glTexCoord2d(1.0, 1.0);
		glVertex2d(x + 15.0, y + 90.0);

		glTexCoord2d(0.0, 1.0);
		glVertex2d(x - 15.0, y + 90.0);

		glEnd();
		glDisable(GL_TEXTURE_2D);
		for (int i = 0; i < nTargets; ++i)
		{
			auto& e = explosion[i];
			if (0 != e.state)
			{
				e.Draw();
			}
		}
		// exit after 62 seconds to make sure the play is at least 60 seconds
		if (time(NULL) - t0 > 62.0)
		{
			return 1;
		}
		glFlush();
		FsSwapBuffers();
		FsSleep(10);
	}
	player.End();
	return 0;
}
